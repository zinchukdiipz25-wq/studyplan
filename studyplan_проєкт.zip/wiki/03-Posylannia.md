# Посилання

| Ресурс | Посилання |
| --- | --- |
| Репозиторій GitHub | https://github.com/<ваш-логін>/studyplan |
| README | https://github.com/<ваш-логін>/studyplan#readme |
| Журнал архітектурних рішень (ADR) | https://github.com/<ваш-логін>/studyplan/tree/main/docs/adr |
| Дошка задач (GitHub Projects) | https://github.com/users/<ваш-логін>/projects/<номер> |
