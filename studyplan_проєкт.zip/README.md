# StudyPlan

**StudyPlan** — навчальний REST API для студентів, який допомагає вести список навчальних завдань із дедлайнами й предметами та бачити, що ще не виконано.

## Можливості

- додавання завдань із назвою, предметом і дедлайном;
- перегляд списку завдань, відсортованого за дедлайном;
- позначення завдання виконаним;
- автоматична інтерактивна документація API (Swagger UI).

## Встановлення та запуск

**Потрібно:** Python 3.11+, Docker (для бази даних PostgreSQL).

```bash
git clone https://github.com/<ваш-логін>/studyplan.git
cd studyplan

# 1. Запустити базу даних
docker compose up -d

# 2. Встановити залежності
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt

# 3. (необов'язково) задати адресу БД; значення за замовчуванням див. у .env.example
export DATABASE_URL=postgresql+psycopg2://studyplan:studyplan@localhost:5432/studyplan

# 4. Запустити сервер
uvicorn app.main:app --reload
```

Після запуску API доступне на <http://127.0.0.1:8000>, документація — на <http://127.0.0.1:8000/docs>.

## Приклад використання

```bash
# Додати завдання
curl -X POST http://127.0.0.1:8000/tasks \
  -H "Content-Type: application/json" \
  -d '{"title": "Практична №6", "subject": "Програмна інженерія", "deadline": "2026-11-25"}'

# Переглянути всі завдання
curl http://127.0.0.1:8000/tasks

# Позначити завдання №1 виконаним
curl -X PATCH http://127.0.0.1:8000/tasks/1/done
```

## Структура проєкту

```
studyplan/
├── app/
│   └── main.py          # API: моделі, схеми й ендпоінти
├── docs/
│   └── adr/             # журнал архітектурних рішень (ADR)
├── docker-compose.yml   # PostgreSQL для локальної розробки
├── requirements.txt     # залежності Python
└── .env.example         # приклад змінних середовища
```

Вимоги й технічне завдання ведуться у вікі проєкту в Notion (посилання — у підсторінці «Посилання» вікі).

## Як зробити внесок

Коротко: гілка від `main` → зміни → pull request. Докладні правила — у [CONTRIBUTING.md](CONTRIBUTING.md). Архітектурні рішення фіксуються у [docs/adr](docs/adr/).

## Ліцензія й автори

Проєкт поширюється за ліцензією [MIT](LICENSE).

Автор: _Прізвище Ім'я_, Рівненський фаховий коледж інформаційних технологій.
